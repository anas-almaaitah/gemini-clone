import React from "react";  
import Sidebar from "./comppnents/Sidebar/Sidebar";
import Main from "./comppnents/Main/Main";
const App = () => {

  return (
    <>
      <Sidebar/>
      <Main/>
    </>
  )
}
export default App
